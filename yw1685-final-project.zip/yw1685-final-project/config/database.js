module.exports = {
 /*if (process.env.NODE_ENV === 'PRODUCTION'){
  const fs = require('fs');
  const path = require('path');
  const fn=path.join(_dirname, 'config.json);
  const data = fs.readFileSync(fn);
  'url' :  conf.dbconf;

  } else {
  'url' : 'mongodb://localhost/finalProj'
// 'url' : 'your-settings-here' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
};*/

'url' = 'mongodb://yw1685:mk98qDnx@class-mongodb.cims.nyu.edu/yw1685'
}

